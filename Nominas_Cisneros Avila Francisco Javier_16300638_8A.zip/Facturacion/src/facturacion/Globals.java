/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facturacion;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author yopri
 */
public class Globals {
    
    public static int id,w,habilitado,empleado,z,idEmpleado,tipo,dias;
    public static float afore,isr,subsidio;
        public static String cod,nombre,apellidos,contrato,departamento,puesto,sueldo;
        public static String[ ]  lista = new  String[20];
        public static String[ ] listaide = new String[20];
        public static String[ ] listatipo = new String[20];
        public static String[ ] listacantidad = new String[20];
        public static String[ ] listafecha = new String[20];
                public static DefaultTableModel modelo = new DefaultTableModel();
                 public static DefaultTableModel modelo1 = new DefaultTableModel(); 
                 public static DefaultTableModel modelo2 = new DefaultTableModel(); 
                
                 public static String semanal,decenal,quincenal;
     public static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        public static SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
        public static String fecha;
        public static int v1,v2;
        
         public static class Conexion{
    private String servidor="jdbc:mysql://localhost/empleados";
    private String user="root";
    private String pass="";
    private String driver="com.mysql.jdbc.Driver";
    private Connection conexion;
    public Conexion() throws SQLException{
    try{
    Class.forName(driver);
    conexion=(Connection) DriverManager.getConnection(servidor,user,pass);
    }
    catch(ClassNotFoundException | SQLException e){
        
    }}
        public Connection getConnection(){
    
    return conexion;
        }
    }
         
 public static void lista() throws SQLException{
  CatTurnos.Conexion conexion = new CatTurnos.Conexion();
        Connection con=conexion.getConnection();  
        Statement st;
        ResultSet rs;
        String sql="SELECT * FROM `periodos` WHERE habilitado=1";
        w=0;
        try{
         st = (Statement) con.createStatement();
        rs=st.executeQuery(sql);
         
        while(rs.next()){
        lista[w]=rs.getString(3);
                      w++;
        }

        con.close();
        rs.close();
        st.close();
        }
        catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error en la consulta");
        }
        
        }
 public static void listaD() throws SQLException{
  CatTurnos.Conexion conexion = new CatTurnos.Conexion();
        Connection con=conexion.getConnection();  
        Statement st;
        ResultSet rs;
        String sql="SELECT * FROM `deptos` WHERE 1";
        w=0;
        try{
         st = (Statement) con.createStatement();
        rs=st.executeQuery(sql);
         
        while(rs.next()){
        lista[w]=rs.getString(2);
                      w++;
        }

        con.close();
        rs.close();
        st.close();
        }
        catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error en la consulta");
        }
        
        }
  public static void listaT() throws SQLException{
  CatTurnos.Conexion conexion = new CatTurnos.Conexion();
        Connection con=conexion.getConnection();  
        Statement st;
        ResultSet rs;
        String sql="SELECT * FROM `turnos` WHERE 1";
        w=0;
        try{
         st = (Statement) con.createStatement();
        rs=st.executeQuery(sql);
         
        while(rs.next()){
        lista[w]=rs.getString(2);
                      w++;
        }

        con.close();
        rs.close();
        st.close();
        }
        catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error en la consulta");
        }
        
        }
   public static void listaP() throws SQLException{
  CatTurnos.Conexion conexion = new CatTurnos.Conexion();
        Connection con=conexion.getConnection();  
        Statement st;
        ResultSet rs;
        String sql="SELECT * FROM `puestos` WHERE 1";
        w=0;
        try{
         st = (Statement) con.createStatement();
        rs=st.executeQuery(sql);
         
        while(rs.next()){
        lista[w]=rs.getString(2);
                      w++;
        }

        con.close();
        rs.close();
        st.close();
        }
        catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error en la consulta");
        }
        
        }
}
 
