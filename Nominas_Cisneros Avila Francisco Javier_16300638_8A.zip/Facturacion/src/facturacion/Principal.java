/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facturacion;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import static facturacion.CatDepartamentos.maximo;
import static facturacion.Globals.*;
import java.io.FileNotFoundException;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author yopri
 */
public class Principal extends javax.swing.JFrame {

    /**
     * Creates new form Principal
     */
    public static float s=0f;
    public Principal() {
        initComponents();
        jPanel5.setVisible(false);
        try {
            listaS();
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            listaD();
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            listaQ();
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        Calendar c1 = Calendar.getInstance();
        int a = c1.get(Calendar.DAY_OF_YEAR);
        try {
            c1.setTime(sdf1.parse(semanal));
        } catch (ParseException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        int b = c1.get(Calendar.DAY_OF_YEAR);
        System.out.println("Uno:"+a);
        System.out.println("Dos:"+b);
        int dif=a-b;
        int semanas=dif/7;
              
        c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        try {
            c2.setTime(sdf1.parse(semanal));
        } catch (ParseException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("s"+semanas);
        c2.add(Calendar.DAY_OF_YEAR,(semanas*7));
        System.out.println("Fecha:"+c2.getTime());
        Calendar c3 = Calendar.getInstance();
        c3.setTime(c2.getTime());
        c2.add(Calendar.DAY_OF_YEAR, 7);
        jLPeriodo.setText("Inicio periodo semanal: " +c3.getTime()+" Termino: "+c2.getTime());
           modelo = new DefaultTableModel();
           String periodo="`periodo` = 1 OR 2";
           try {
            tabla(periodo);
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
           
        jtSueldos.setModel(modelo);
                  modelo.addColumn("Afore");
                             int i=jtSueldos.getRowCount();
                             System.out.println("I::"+i);
        for(int j=0;j<i;j++){
             String year=jtSueldos.getValueAt(j, 4).toString();
            System.out.println("año"+year);
            Calendar af1 = Calendar.getInstance();
            try { 
                af1.setTime(sdf.parse(year));
            } catch (ParseException ex) {
                Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
            }
             Calendar fechaActual = Calendar.getInstance();
            int y= fechaActual.get(Calendar.YEAR) - af1.get(Calendar.YEAR);
            int mes =fechaActual.get(Calendar.MONTH)- af1.get(Calendar.MONTH);
       int dia = fechaActual.get(Calendar.DATE)-  af1.get(Calendar.DATE);
       //Se ajusta el año dependiendo el mes y el día
       
       if(mes<0 || (mes==0 && dia<0)){
          y--;
         }
       System.out.println("edad"+y);
       float base = 60000*20;
       float diferencia = 65-y;
       float r1=base/diferencia;
       float r2 = r1/12;
       System.out.println("Ahorro mensual:" +r2);
       jtSueldos.setValueAt(r2, j, 5);
            try {
                System.out.println("Empleado:"+j+"Afore"+r2);
                agregarA(j+1,r2);
            } catch (SQLException ex) {
                Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        btPrenomina = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        btRecibo = new javax.swing.JButton();
        jSeparator4 = new javax.swing.JSeparator();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jSeparator6 = new javax.swing.JSeparator();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtSueldos = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jLPeriodo = new javax.swing.JLabel();
        jcPeriodo = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jSeparator7 = new javax.swing.JSeparator();
        jSeparator8 = new javax.swing.JSeparator();
        btCalcular = new javax.swing.JButton();
        btIncidencias = new javax.swing.JButton();
        btSueldos = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtIncidencias = new javax.swing.JTable();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        jMenu5 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();
        jMenu7 = new javax.swing.JMenu();
        jMenu8 = new javax.swing.JMenu();
        jMenu9 = new javax.swing.JMenu();
        jMenu10 = new javax.swing.JMenu();
        jMenu11 = new javax.swing.JMenu();
        jMenu12 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(900, 500));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jButton1.setText("Home");
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 70, -1));

        jSeparator1.setBackground(new java.awt.Color(204, 204, 204));
        jSeparator1.setForeground(new java.awt.Color(255, 255, 255));
        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 0, 10, 40));

        btPrenomina.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        btPrenomina.setText("Prenomina");
        btPrenomina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btPrenominaActionPerformed(evt);
            }
        });
        jPanel1.add(btPrenomina, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 10, 120, -1));

        jSeparator2.setBackground(new java.awt.Color(204, 204, 204));
        jSeparator2.setForeground(new java.awt.Color(255, 255, 255));
        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 10, 40));

        btRecibo.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        btRecibo.setText("Sobre-Recibo");
        btRecibo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btReciboActionPerformed(evt);
            }
        });
        jPanel1.add(btRecibo, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, 120, -1));

        jSeparator4.setBackground(new java.awt.Color(204, 204, 204));
        jSeparator4.setForeground(new java.awt.Color(255, 255, 255));
        jSeparator4.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jPanel1.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 0, 10, 40));

        jButton4.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jButton4.setText("4");
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 10, 40, -1));

        jButton5.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jButton5.setText("1");
        jPanel1.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 10, 40, -1));

        jButton6.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jButton6.setText("2");
        jPanel1.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 10, 40, -1));

        jButton7.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jButton7.setText("3");
        jPanel1.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 10, 40, -1));

        jSeparator6.setBackground(new java.awt.Color(204, 204, 204));
        jSeparator6.setForeground(new java.awt.Color(255, 255, 255));
        jSeparator6.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jPanel1.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 0, 10, 40));

        jButton8.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jButton8.setText("-----");
        jPanel1.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 10, -1, -1));

        jButton9.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jButton9.setText("Salir");
        jPanel1.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 10, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 40));

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton12.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jButton12.setText("Empresa");
        jPanel2.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 100, 20));

        jButton13.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jButton13.setText("Periodo");
        jButton13.setMaximumSize(new java.awt.Dimension(71, 21));
        jButton13.setMinimumSize(new java.awt.Dimension(71, 21));
        jButton13.setPreferredSize(new java.awt.Dimension(71, 21));
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 100, 20));

        jButton14.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jButton14.setText("Catalogos");
        jButton14.setMaximumSize(new java.awt.Dimension(71, 21));
        jButton14.setMinimumSize(new java.awt.Dimension(71, 21));
        jButton14.setPreferredSize(new java.awt.Dimension(71, 21));
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 100, 20));

        jButton18.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jButton18.setText("Procesos");
        jButton18.setMaximumSize(new java.awt.Dimension(71, 21));
        jButton18.setMinimumSize(new java.awt.Dimension(71, 21));
        jButton18.setPreferredSize(new java.awt.Dimension(71, 21));
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton18, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 100, 20));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 100, 420));

        jSeparator3.setBackground(new java.awt.Color(204, 204, 204));
        jSeparator3.setForeground(new java.awt.Color(255, 255, 255));
        jSeparator3.setOrientation(javax.swing.SwingConstants.VERTICAL);
        getContentPane().add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 10, 40));

        jSeparator5.setBackground(new java.awt.Color(204, 204, 204));
        jSeparator5.setForeground(new java.awt.Color(255, 255, 255));
        jSeparator5.setOrientation(javax.swing.SwingConstants.VERTICAL);
        getContentPane().add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 10, 40));

        jPanel3.setBackground(new java.awt.Color(153, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jtSueldos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jtSueldos.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jtSueldos.setEditingRow(0);
        jtSueldos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtSueldosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jtSueldos);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 350));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 110, 840, 350));

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLPeriodo.setBackground(new java.awt.Color(0, 153, 153));
        jLPeriodo.setText("Periodo: ");
        jPanel4.add(jLPeriodo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 20));

        jcPeriodo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todos los del periodo", "Semanal", "Quincenal", " " }));
        jPanel4.add(jcPeriodo, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 30, 210, -1));

        jLabel1.setBackground(new java.awt.Color(0, 153, 153));
        jLabel1.setText("Filtro:");
        jPanel4.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 80, 20));
        jPanel4.add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 840, -1));
        jPanel4.add(jSeparator8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 58, 840, -1));

        btCalcular.setText("Calcular");
        btCalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCalcularActionPerformed(evt);
            }
        });
        jPanel4.add(btCalcular, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 30, -1, -1));

        btIncidencias.setText("Incidencias");
        btIncidencias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btIncidenciasActionPerformed(evt);
            }
        });
        jPanel4.add(btIncidencias, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 30, -1, -1));

        btSueldos.setText("Sueldos");
        btSueldos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSueldosActionPerformed(evt);
            }
        });
        jPanel4.add(btSueldos, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 30, 80, -1));

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 40, -1, 70));

        jPanel5.setBackground(new java.awt.Color(153, 255, 255));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jtIncidencias.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jtIncidencias.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jtIncidencias.setEditingRow(0);
        jtIncidencias.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtIncidenciasMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jtIncidencias);

        jPanel5.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 350));

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 110, 840, 350));

        jMenuBar1.setBackground(new java.awt.Color(239, 239, 239));

        jMenu1.setText("Archivo");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edicion");
        jMenuBar1.add(jMenu2);

        jMenu3.setText("Ver");
        jMenuBar1.add(jMenu3);

        jMenu4.setText("Movimientos");
        jMenuBar1.add(jMenu4);

        jMenu5.setText("Vistas");
        jMenuBar1.add(jMenu5);

        jMenu6.setText("Reportes");
        jMenuBar1.add(jMenu6);

        jMenu7.setText("Catalogos");
        jMenuBar1.add(jMenu7);

        jMenu8.setText("Procesos");
        jMenuBar1.add(jMenu8);

        jMenu9.setText("Interfaz");
        jMenuBar1.add(jMenu9);

        jMenu10.setText("Tablas");
        jMenuBar1.add(jMenu10);

        jMenu11.setText("Herramientas");
        jMenuBar1.add(jMenu11);

        jMenu12.setText("Ayuda");
        jMenuBar1.add(jMenu12);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        // TODO add your handling code here:
        
        
        
        
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        // TODO add your handling code here:
        Catalogos ct =new Catalogos();
        ct.setVisible(true);
        this.dispose();
        this.setVisible(false);
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        // TODO add your handling code here:
        
        
    }//GEN-LAST:event_jButton13ActionPerformed

    private void btPrenominaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPrenominaActionPerformed
           int a= jcPeriodo.getSelectedIndex();
              modelo = new DefaultTableModel();
              modelo2=new DefaultTableModel();
           String periodo="";
            if(a==0){
            periodo="`periodo`= 1 OR 2 ";
               try {
            tabla(periodo);
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
            }
            else if(a==1){
            periodo="`periodo`= 1";
              try {
            tabla(periodo);
    
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
            Calendar c1 = Calendar.getInstance();
        int A = c1.get(Calendar.DAY_OF_YEAR);
        try {
            c1.setTime(sdf1.parse(semanal));
        } catch (ParseException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        int b = c1.get(Calendar.DAY_OF_YEAR);
        System.out.println("Uno:"+A);
        System.out.println("Dos:"+b);
        int dif=A-b;
        int semanas=dif/7;
              
        c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        try {
            c2.setTime(sdf1.parse(semanal));
        } catch (ParseException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("s"+semanas);
        c2.add(Calendar.DAY_OF_YEAR,(semanas*7));
        System.out.println("Fecha:"+c2.getTime());
        Calendar c3 = Calendar.getInstance();
        c3.setTime(c2.getTime());
        c2.add(Calendar.DAY_OF_YEAR, 7);
        jLPeriodo.setText("Inicio periodo semanal: " +c3.getTime()+" Termino: "+c2.getTime());
                modelo2.addColumn("ID");
        modelo2.addColumn("Nombre");
         modelo2.addColumn(""+sdf.format(c3.getTime()));
         for(int i=0;i<7;i++){
            c3.add(Calendar.DAY_OF_MONTH, 1);
            modelo2.addColumn(""+sdf.format(c3.getTime()));
            }
         
            }
            
            else if(a==2){
            periodo="`periodo`= 2";
              try {
            tabla(periodo);
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
            Calendar c1 = Calendar.getInstance();
        int A = c1.get(Calendar.DAY_OF_YEAR);
        try {
            c1.setTime(sdf1.parse(semanal));
        } catch (ParseException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        int b = c1.get(Calendar.DAY_OF_YEAR);
        System.out.println("Uno:"+A);
        System.out.println("Dos:"+b);
        int dif=A-b;
        int semanas=dif/15;
              
        c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        try {
            c2.setTime(sdf1.parse(semanal));
        } catch (ParseException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("s"+semanas);
        c2.add(Calendar.DAY_OF_YEAR,(semanas*15));
        System.out.println("Fecha:"+c2.getTime());
        Calendar c3 = Calendar.getInstance();
        c3.setTime(c2.getTime());
        c2.add(Calendar.DAY_OF_YEAR, 15);
        jLPeriodo.setText("Inicio periodo quincenal: " +c3.getTime()+" Termino: "+c2.getTime());
        modelo2.addColumn("ID");
        modelo2.addColumn("Nombre");
         modelo2.addColumn(""+sdf.format(c3.getTime()));
       for(int i=0;i<15;i++){
            c3.add(Calendar.DAY_OF_MONTH, 1);
            modelo2.addColumn(""+sdf.format(c3.getTime()));
            }
            }
            System.out.println(""+a);
            System.out.println(""+periodo);
            jtSueldos.setModel(modelo);
            btCalcular.setEnabled(true);
               for(int i=0;i<jtSueldos.getRowCount();i++){
            modelo2.addRow(new Object[]{jtSueldos.getValueAt(i, 0),jtSueldos.getValueAt(i, 1)});

        }
         try {
            incidencias();
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
          
    }//GEN-LAST:event_btPrenominaActionPerformed

    private void btCalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCalcularActionPerformed
        // TODO add your handling code here:
        int i=jtSueldos.getRowCount();
        int p=jcPeriodo.getSelectedIndex();
        System.out.println(""+i);
        if(p==0){
                    jtSueldos.setModel(modelo);
            if(modelo.getColumnCount()>4 && modelo.getColumnCount()<10){
        modelo.addColumn("Sueldo Semanal");
        modelo.addColumn("Sueldo Quincenal");
        modelo.addColumn("ISR");
        modelo.addColumn("Importe");
        modelo.addColumn("Subsidio al Empleo");
            }
        for(int j=0;j<i;j++){
           Float valor= Float.parseFloat(jtSueldos.getValueAt(j, 2).toString());
            System.out.println(""+valor);
            String a= jtSueldos.getValueAt(j, 3).toString();
            System.out.println(""+a);
           
            if(a.equals("1")){
                float sdi=valor*7;
            jtSueldos.setValueAt(sdi, j, 6);
           float isr=isr(valor);
            jtSueldos.setValueAt(isr, j, 8);
                float importe = importe(isr,valor);
            jtSueldos.setValueAt(importe, j, 9);
            jtSueldos.setValueAt(s, j, 10);
            
                }/////////termina if
            else if(a.equals("2")){
             jtSueldos.setValueAt((valor*15), j, 7);
           float isr= isr(valor);
            jtSueldos.setValueAt(isr, j, 8);
            float importe = importe(isr,valor);
            jtSueldos.setValueAt(importe, j, 9);
            jtSueldos.setValueAt(s, j, 10);
            }
            
        }
        }
        /////////////////////////////////////////////////////////////Semanal
        else if(p==1){
                    jtSueldos.setModel(modelo);
         if(modelo.getColumnCount()>0 && modelo.getColumnCount()<14){
        modelo.addColumn("Sueldo Semanal");
                modelo.addColumn("ISR");
                modelo.addColumn("Importe");
                modelo.addColumn("Subsidio al Empleo");
            }
        for(int j=0;j<i;j++){
            
            Float valor= Float.parseFloat(jtSueldos.getValueAt(j, 2).toString());
            String a= jtSueldos.getValueAt(j, 3).toString();
            if(a.equals("1")){
                float resta=0;
                for(int w=0; w<z; w++){
                if( listaide[w].equals(jtSueldos.getValueAt(j,0).toString())){
                    if(listatipo[w].equals("FINJ")){
                    resta=resta+valor*Integer.parseInt(listacantidad[w]);
                } 
                }
                }
            jtSueldos.setValueAt((valor*7), j, 5);
           float isr = isr(valor);
            
            jtSueldos.setValueAt(isr, j, 6);
                float importe = importe(isr,valor);
            jtSueldos.setValueAt(importe-resta, j, 7);
            jtSueldos.setValueAt(s, j, 8);
                }
        }
        }
        else if(p==2){
            jtSueldos.setModel(modelo);
         if(modelo.getColumnCount()>4 && modelo.getColumnCount()<20){
        modelo.addColumn("Sueldo Quincenal");
                modelo.addColumn("ISR");
                modelo.addColumn("Importe");
                modelo.addColumn("Subsidio al Empleo");
            }
        for(int j=0;j<i;j++){
           Float valor= Float.parseFloat(jtSueldos.getValueAt(j, 2).toString());
            System.out.println(""+valor);
            String a= jtSueldos.getValueAt(j, 3).toString();
            System.out.println("A:"+a);
            if(a.equals("2")){
                float resta=0;
                for(int w=0; w<z; w++){
                if( listaide[w].equals(jtSueldos.getValueAt(j,0).toString())){
                    if(listatipo[w].equals("FINJ")){
                    resta=resta+valor*Integer.parseInt(listacantidad[w]);
                } 
                }
                }
            jtSueldos.setValueAt((valor*15), j, 5);
           float isr = isr(valor);
            jtSueldos.setValueAt(isr, j, 6);
                float importe = importe(isr,valor);
            jtSueldos.setValueAt(importe-resta, j, 7);
            jtSueldos.setValueAt(s, j, 8);
                }
        }
        }
        
        btCalcular.setEnabled(false);
       
    }//GEN-LAST:event_btCalcularActionPerformed

    private void jtSueldosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtSueldosMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jtSueldosMouseClicked

    private void btIncidenciasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btIncidenciasActionPerformed
        // TODO add your handling code here:
        jPanel5.setVisible(true);
        jPanel3.setVisible(false);
        jtIncidencias.setModel(modelo2);
     
                modelo2= new DefaultTableModel();
      
      
    }//GEN-LAST:event_btIncidenciasActionPerformed

    private void jtIncidenciasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtIncidenciasMouseClicked
        // TODO add your handling code here:
        int fila= jtIncidencias.getSelectedRow();
        int columna=jtIncidencias.getSelectedColumn();
        System.out.println(""+columna);
        fecha=jtIncidencias.getColumnName(columna);
        Globals.empleado=Integer.parseInt(jtIncidencias.getValueAt(fila, 0).toString());
        if(columna>1){
        Nemonicos n = new Nemonicos();
        n.setVisible(true);
        }
    }//GEN-LAST:event_jtIncidenciasMouseClicked

    private void btSueldosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSueldosActionPerformed
        // TODO add your handling code here:
        jPanel3.setVisible(true);
        jPanel5.setVisible(false);
    }//GEN-LAST:event_btSueldosActionPerformed

    private void btReciboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btReciboActionPerformed
        // TODO add your handling code here:
        dias=0;
        int f=jtSueldos.getSelectedRow();
        System.out.println("Fila::::"+f);
        idEmpleado = Integer.parseInt(jtSueldos.getValueAt(f,0).toString());
        tipo=Integer.parseInt(modelo.getValueAt(f, 3).toString());
          for(int w=0; w<z; w++){
                if( listaide[w].equals(jtSueldos.getValueAt(f,0).toString())){
                    if(listatipo[w].equals("FINJ")){
                    dias=dias+Integer.parseInt(listacantidad[w]);
                } 
                }
                }
          isr=Float.parseFloat(jtSueldos.getValueAt(f, 6).toString());
          subsidio=Float.parseFloat(jtSueldos.getValueAt(f, 8).toString());
          System.out.println("DIAS:"+dias);
        String s="`empleado_cd` = "+idEmpleado;
        try {
            Empleado(s);
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }

        Recibo r = new Recibo();
        r.setVisible(true);
    }//GEN-LAST:event_btReciboActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }
    public static class Conexion{
    private String servidor="jdbc:mysql://localhost/empleados";
    private String user="root";
    private String pass="";
    private String driver="com.mysql.jdbc.Driver";
    private Connection conexion;
    public Conexion() throws SQLException{
    try{
    Class.forName(driver);
    conexion=(Connection) DriverManager.getConnection(servidor,user,pass);
    }
    catch(ClassNotFoundException | SQLException e){
        
    }}
        public Connection getConnection(){
    
    return conexion;
        }
    }
     public static void tabla(String periodo) throws SQLException{
    CatTurnos.Conexion conexion = new CatTurnos.Conexion();
        Connection con=conexion.getConnection();
        Statement st;
        ResultSet rs;
        String sql="SELECT  `empleado_cd`,`nombre`,`salario_diario`,`periodo`,`fecha_alta` FROM `empleados` WHERE "+periodo;
        try{
         st = (Statement) con.createStatement();
        rs=st.executeQuery(sql);
        ResultSetMetaData md=rs.getMetaData();
            int columnas= md.getColumnCount();
            for (int i = 1; i <= columnas; i++) {
                 modelo.addColumn(md.getColumnLabel(i));}
        while(rs.next()){
          Object[] fila = new Object[columnas];
            for (int i = 0; i < columnas; i++) {fila[i]=rs.getObject(i+1);}
            modelo.addRow(fila);
            }
        con.close();
        rs.close();
        st.close();
        }
        catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error en la consulta");
                System.out.println(""+e);
        }
    }
     public static void listaS() throws SQLException{
  CatTurnos.Conexion conexion = new CatTurnos.Conexion();
        Connection con=conexion.getConnection();  
        Statement st;
        ResultSet rs;
        String sql="SELECT `habilitado`, `fecha` FROM `periodos` WHERE `tipo` = 'semanal'";
        w=0;
        try{
         st = (Statement) con.createStatement();
        rs=st.executeQuery(sql);
         while(rs.next()){
     
        habilitado=rs.getInt(1);
        semanal = sdf1.format(rs.getDate(2));
             System.out.println(""+semanal);
         }
        con.close();
        rs.close();
        st.close();
        }
        catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error en la consulta");
                System.out.println(""+e);
        }
        }
        public static void listaD() throws SQLException{
  CatTurnos.Conexion conexion = new CatTurnos.Conexion();
        Connection con=conexion.getConnection();  
        Statement st;
        ResultSet rs;
        String sql="SELECT `habilitado`, `fecha` FROM `periodos` WHERE `tipo` = 'decenal'";
        w=0;
        try{
         st = (Statement) con.createStatement();
        rs=st.executeQuery(sql);
         while(rs.next()){
     
        habilitado=rs.getInt(1);
        decenal = sdf1.format(rs.getDate(2));
             System.out.println(""+semanal);
         }
        con.close();
        rs.close();
        st.close();
        }
        catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error en la consulta");
                System.out.println(""+e);
        }
        }
           public static void listaQ() throws SQLException{
  CatTurnos.Conexion conexion = new CatTurnos.Conexion();
        Connection con=conexion.getConnection();  
        Statement st;
        ResultSet rs;
        String sql="SELECT `habilitado`, `fecha` FROM `periodos` WHERE `tipo` = 'quincenal'";
        w=0;
        try{
         st = (Statement) con.createStatement();
        rs=st.executeQuery(sql);
         while(rs.next()){
     
        habilitado=rs.getInt(1);
        quincenal = sdf1.format(rs.getDate(2));
             System.out.println(""+semanal);
         }
        con.close();
        rs.close();
        st.close();
        }
        catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error en la consulta");
                System.out.println(""+e);
        }
        
        }
           public static float isr(float valor){
               
                float sdi30= valor*30;
            float porcentaje=0f,cuota=0f,inferior=0f;
             if(sdi30>=0.01f && sdi30 <= 578.52){inferior=0.01f;porcentaje=1.92f;cuota=0.0f;}
            else if (sdi30>=578.53 && sdi30<= 4910.18f ){inferior=578.53f;porcentaje=6.40f; cuota=11.11f;}
            else if (sdi30>=4910.19 && sdi30<= 8629.20f ){inferior=4910.19f;porcentaje=10.88f; cuota=288.33f;}
             else if (sdi30>=8629.21 && sdi30<= 10031.07f ){inferior=8629.21f;porcentaje=16f; cuota=692.96f;}
              else if (sdi30>=10031.08 && sdi30<= 12009.94f ){inferior=10031.08f;porcentaje=17.92f; cuota=917.26f;}
             else if (sdi30>=12009.95 && sdi30<= 24222.31f ){inferior=12009.95f;porcentaje=21.36f; cuota=1271.87f;}
             else if (sdi30>=24222.32 && sdi30<= 38177.69f ){inferior=24222.32f;porcentaje=23.52f; cuota=3880.44f;}
             else if (sdi30>=38177.70 && sdi30<= 72887.50f ){inferior=38177.70f;porcentaje=30f; cuota=7162.74f;}
             else if (sdi30>=72887.51 && sdi30<= 97183.33f ){inferior=72887.51f;porcentaje=32f; cuota=17575.69f;}
              else if (sdi30>=98183.34 && sdi30<= 291550f ){inferior=98183.34f;porcentaje=34f; cuota=25350.35f;}
             else if (sdi30>=291550.01){inferior=291550.01f;porcentaje=35f; cuota=91435.02f;}
            float isr=sdi30-inferior;
            isr=(isr*(porcentaje/100));
            isr=isr+cuota;
         
           return isr;}
           public static float importe(float isr,float sdi30 ){
               float importe=0f;
               importe = sdi30*30;

               if(importe>=0.01 && importe<=1786.96){s=407.02f;}
               else if(importe>=1768.97 && importe<=2653.38){s=406.83f;}
               else if(importe>=2653.39 && importe<=3472.84){s=406.62f;}
               else if(importe>=3472.85 && importe<=3537.87){s=392.77f;}
               else if(importe>=3537.88 && importe<=4446.15){s=382.46f;}
               else if(importe>=4446.16 && importe<=4717.18){s=354.23f;}
               else if(importe>=4717.19 && importe<=5335.42){s=324.87f;}
               else if(importe>=5335.43 && importe<=6224.67){s=294.63f;}
               else if(importe>=6224.68 && importe<=7113.90){s=253.54f;}
               else if(importe>=7113.91 && importe<=7382.33){s=217.61f;}
               else if(importe>=7382.33){s=0.00f;}
               if(s==0.00f)
               {importe=importe-isr;}
               else{
               importe=importe-(isr-s);
               }
               return importe;
           }
                 public static void incidencias() throws SQLException{
          Conexion conexion = new Conexion();
        Connection con=conexion.getConnection();
        Statement st;
        ResultSet rs;
        String sql="SELECT `cod_em`,`tipo`,`cantidad`,`fecha` FROM `incidencias` WHERE 1";
        try{
         st = (Statement) con.createStatement();
        rs=st.executeQuery(sql);
        z=0;
        while(rs.next()){
        int idE=rs.getInt(1);
        listaide[z] = String.valueOf(idE);
        String tipo = rs.getString(2);
        listatipo[z] = tipo; 
        int cantidad = rs.getInt(3);
        listacantidad[z] = String.valueOf(cantidad);
        String fecha = rs.getString(4);
        listafecha[z] = fecha;
        for(int i=0; i<modelo2.getRowCount(); i++){
        if (idE==Integer.parseInt(modelo2.getValueAt(i, 0).toString())){
             modelo2.setValueAt(cantidad+tipo,i,modelo2.findColumn(fecha) );
        }
        }
           z++;
        }
        con.close();
        rs.close();
        st.close();
        }
        catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error en la consulta de incidencias");
        }
        
    }
                 public static void Empleado(String empleado) throws SQLException{
        Conexion conexion = new Conexion();
        Connection con=conexion.getConnection();
        Statement st;
        ResultSet rs;
        String sql="SELECT  `empleado_cd`,`nombre`,`apellido`,`tipo_con_cd`,`dpt_cd`,`puesto_cd`,`salario_diario`,`afore` FROM `empleados` WHERE "+empleado;
        try{
         st = (Statement) con.createStatement();
        rs=st.executeQuery(sql);
        while(rs.next()){
            cod=rs.getString(1);
            nombre=rs.getString(2);
            apellidos=rs.getString(3);
            contrato=rs.getString(4);
            departamento=rs.getString(5);
            puesto=rs.getString(6);
            sueldo=rs.getString(7);
            afore=rs.getFloat(8);
            }
        con.close();
        rs.close();
        st.close();
        }
        catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error en la consulta");
                System.out.println(""+e);
        }
    }
                     public static int agregarA(int em, float afore) throws SQLException, FileNotFoundException{
        int correcto=0;
        Conexion conexion = new Conexion();
        Connection con=conexion.getConnection();
                  
        String sql="UPDATE `empleados` SET `afore` = (?) WHERE empleado_cd =  "+em;
             PreparedStatement ps=null;
        try{
            ps = con.prepareStatement(sql);
            ps.setFloat(1, afore);
            ps.executeUpdate();            
           correcto=1;
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Error al ingresar departamento");
            System.out.println(""+e);
        }

        return correcto;
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btCalcular;
    private javax.swing.JButton btIncidencias;
    private javax.swing.JButton btPrenomina;
    private javax.swing.JButton btRecibo;
    private javax.swing.JButton btSueldos;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLPeriodo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu10;
    private javax.swing.JMenu jMenu11;
    private javax.swing.JMenu jMenu12;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenu jMenu9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JComboBox<String> jcPeriodo;
    private javax.swing.JTable jtIncidencias;
    private javax.swing.JTable jtSueldos;
    // End of variables declaration//GEN-END:variables
}
